import fs from "fs";
import path from "path";
import express from "express";
import { createServer as createViteServer } from "vite";
import { initializeApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  getDocs, 
  doc, 
  setDoc, 
  deleteDoc,
  writeBatch
} from "firebase/firestore";

const app = express();
const PORT = 3000;

// Body parser
app.use(express.json({ limit: "50mb" }));

// Firestore Operation Types
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: null,
      email: null,
      emailVerified: null,
      isAnonymous: null,
      tenantId: null,
      providerInfo: []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Initialize Firebase from config file
let db: any = null;
try {
  const configPath = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    const config = JSON.parse(fs.readFileSync(configPath, "utf8"));
    const firebaseApp = initializeApp({
      apiKey: config.apiKey,
      authDomain: config.authDomain,
      projectId: config.projectId,
      storageBucket: config.storageBucket,
      messagingSenderId: config.messagingSenderId,
      appId: config.appId
    });
    
    // Pass the custom firestoreDatabaseId if configured
    if (config.firestoreDatabaseId) {
      db = getFirestore(firebaseApp, config.firestoreDatabaseId);
    } else {
      db = getFirestore(firebaseApp);
    }
    console.log("Firebase initialized successfully with Project ID:", config.projectId);
  } else {
    console.warn("firebase-applet-config.json not found. Database features will run in memory fallback mode.");
  }
} catch (error) {
  console.error("Failed to initialize Firebase:", error);
}

// In-memory fallback if Firestore isn't available
let memoryTabs: any[] = [];

// API Route: Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", firebaseConnected: !!db });
});

// API Route: GET all whiteboard tabs
app.get("/api/tabs", async (req, res) => {
  try {
    if (db) {
      const tabsCol = collection(db, "whiteboard_tabs");
      let snapshot;
      try {
        snapshot = await getDocs(tabsCol);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, "whiteboard_tabs");
      }
      const tabs = snapshot.docs.map(doc => {
        const data = doc.data();
        let history = data.history;
        if (typeof history === "string") {
          try {
            history = JSON.parse(history);
          } catch (e) {
            history = [];
          }
        }
        return {
          id: doc.id,
          ...data,
          history
        };
      });
      
      // Sort tabs so order remains consistent (e.g. by index or creation time)
      tabs.sort((a: any, b: any) => (a.order || 0) - (b.order || 0));
      return res.json(tabs);
    } else {
      return res.json(memoryTabs);
    }
  } catch (error: any) {
    console.error("Error fetching tabs:", error);
    res.status(500).json({ error: "Failed to fetch tabs", details: error.message });
  }
});

// API Route: POST (bulk save/sync) whiteboard tabs
app.post("/api/tabs/sync", async (req, res) => {
  try {
    const { tabs } = req.body;
    if (!Array.isArray(tabs)) {
      return res.status(400).json({ error: "Invalid payload. 'tabs' must be an array." });
    }

    if (db) {
      // Clean up tabs data to omit heavy imageElement objects which don't serialize
      const cleanedTabs = tabs.map((t: any, index: number) => {
        const cleanElements = (t.elements || []).map((el: any) => {
          const { imageElement, ...rest } = el;
          return rest;
        });
        
        const cleanHistory = (t.history || []).map((histList: any) => {
          return (histList || []).map((el: any) => {
            const { imageElement, ...rest } = el;
            return rest;
          });
        });

        return {
          id: t.id,
          name: t.name || "Untitled Whiteboard",
          elements: cleanElements,
          history: JSON.stringify(cleanHistory),
          historyIndex: typeof t.historyIndex === "number" ? t.historyIndex : 0,
          pan: t.pan || { x: 0, y: 0 },
          zoom: typeof t.zoom === "number" ? t.zoom : 1.0,
          order: index,
          updatedAt: new Date().toISOString()
        };
      });

      // Bulk write using batch
      const batch = writeBatch(db);
      for (const tab of cleanedTabs) {
        const docRef = doc(db, "whiteboard_tabs", tab.id);
        batch.set(docRef, tab);
      }
      try {
        await batch.commit();
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, "whiteboard_tabs");
      }

      return res.json({ success: true, count: cleanedTabs.length });
    } else {
      memoryTabs = tabs;
      return res.json({ success: true, count: memoryTabs.length, fallback: true });
    }
  } catch (error: any) {
    console.error("Error syncing tabs:", error);
    res.status(500).json({ error: "Failed to sync tabs", details: error.message });
  }
});

// API Route: POST single tab update
app.post("/api/tabs", async (req, res) => {
  try {
    const tab = req.body;
    if (!tab || !tab.id) {
      return res.status(400).json({ error: "Invalid tab payload" });
    }

    // Clean element serializations
    const cleanElements = (tab.elements || []).map((el: any) => {
      const { imageElement, ...rest } = el;
      return rest;
    });

    const cleanHistory = (tab.history || []).map((histList: any) => {
      return (histList || []).map((el: any) => {
        const { imageElement, ...rest } = el;
        return rest;
      });
    });

    const cleanedTab = {
      id: tab.id,
      name: tab.name || "Untitled Whiteboard",
      elements: cleanElements,
      history: JSON.stringify(cleanHistory),
      historyIndex: typeof tab.historyIndex === "number" ? tab.historyIndex : 0,
      pan: tab.pan || { x: 0, y: 0 },
      zoom: typeof tab.zoom === "number" ? tab.zoom : 1.0,
      order: typeof tab.order === "number" ? tab.order : 0,
      updatedAt: new Date().toISOString()
    };

    if (db) {
      const docRef = doc(db, "whiteboard_tabs", tab.id);
      try {
        await setDoc(docRef, cleanedTab);
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, `whiteboard_tabs/${tab.id}`);
      }
      return res.json({ success: true, tab: { ...cleanedTab, history: cleanHistory } });
    } else {
      const existingIdx = memoryTabs.findIndex(t => t.id === tab.id);
      if (existingIdx > -1) {
        memoryTabs[existingIdx] = { ...cleanedTab, history: cleanHistory };
      } else {
        memoryTabs.push({ ...cleanedTab, history: cleanHistory });
      }
      return res.json({ success: true, tab: { ...cleanedTab, history: cleanHistory }, fallback: true });
    }
  } catch (error: any) {
    console.error("Error saving tab:", error);
    res.status(500).json({ error: "Failed to save tab", details: error.message });
  }
});

// API Route: DELETE a whiteboard tab
app.delete("/api/tabs/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (db) {
      const docRef = doc(db, "whiteboard_tabs", id);
      try {
        await deleteDoc(docRef);
      } catch (err) {
        handleFirestoreError(err, OperationType.DELETE, `whiteboard_tabs/${id}`);
      }
      return res.json({ success: true, message: `Tab ${id} deleted` });
    } else {
      memoryTabs = memoryTabs.filter(t => t.id !== id);
      return res.json({ success: true, message: `Tab ${id} deleted from memory` });
    }
  } catch (error: any) {
    console.error("Error deleting tab:", error);
    res.status(500).json({ error: "Failed to delete tab", details: error.message });
  }
});

// Vite middleware and production static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
